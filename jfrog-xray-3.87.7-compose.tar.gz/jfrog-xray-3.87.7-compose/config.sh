#!/bin/bash

#Fail immediately on any error
#set -e

# This file is for preparing all the needed files and directories on the host.
# These directories are mounted into the docker containers.

SCRIPT_DIR=$(dirname $0)
SCRIPT_HOME="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
COMPOSE_HOME="$(cd ${SCRIPT_HOME} && pwd)"
ENV="${COMPOSE_HOME}/.env"

source "${ENV}"

JF_PROJECT_NAME="xray"

. ${SCRIPT_HOME}/bin/systemYamlHelper.sh
. ${SCRIPT_HOME}/bin/dockerComposeHelper.sh #Important that this be included second - overwrites some methods

# Variables used for validations
RPM_DEB_RECOMMENDED_MIN_RAM=4718592           # 4.5G Total RAM => 4.5*1024*1024k=4718592
RPM_DEB_RECOMMENDED_MAX_USED_STORAGE=90       # needs more than 10% available storage
RPM_DEB_RECOMMENDED_MIN_CPU=3                 # needs more than 3 CPU Cores

PRODUCT_NAME="$XRAY_LABEL"
IS_POSTGRES_REQUIRED="$FLAG_Y"

# Rabbitmq cookie value. (shared.rabbitMq.erlangCookie.value)
JF_SHARED_RABBITMQ_ERLANGCOOKIE_VALUE=JFXR_RABBITMQ_COOKIE

_isMongoNotNeeded(){
  docker_getSystemValue "shared.mongo" "JF_SHARED_MONGO" "${SYSTEM_YAML_FILE}"
  if [ -z "${YAML_VALUE}" ]; then
    return 0;
  fi
  return 1;
}

_setMongoDataRoot() {
  if _isMongoNotNeeded; then
    unset MONGODB_DATA_ROOT
  else
    MONGODB_DATA_ROOT="${JF_ROOT_DATA_DIR}${THIRDPARTY_DATA_ROOT}/mongodb"
  fi
}

docker_hook_setDirInfo(){
  logDebug "Method ${FUNCNAME[0]}"

  # Rabbitmq
  RABBITMQ_DATA_ROOT="${JF_ROOT_DATA_DIR}${THIRDPARTY_DATA_ROOT}/rabbitmq"
  POSTGRESQL_DATA_ROOT="${JF_ROOT_DATA_DIR}${THIRDPARTY_DATA_ROOT}/postgres"
  _setMongoDataRoot
}

_createRabbitMQConf() {
  # create configuration file. This is necessary
  local configFile="$1"
  local confFile="${COMPOSE_HOME}/third-party/rabbitmq/rabbitmq.conf"

  if [ ! -f "$confFile" ]; then
    confFile="${SCRIPT_HOME}/rabbitmq/rabbitmq.conf"
  fi

  [ -f "$confFile" ] || { warn "Could not find the file: [rabbitmq.conf]" && return; }

  cp "$confFile" "$rabbitMQScriptFolder" || errorExit "Could not copy rabbitmq configuration."
}

setupRabbitMQCluster() {

  logDebug "Method ${FUNCNAME[0]}"

  local rabbitMqPort="5672"
  local amqpProtocol="amqp"

  # Copy the rabbitmq clustering script to the app folder
  local rabbitMQScriptFolder="${JF_ROOT_DATA_DIR}/app/third-party/rabbitmq"
  mkdir -p $rabbitMQScriptFolder || errorExit "Setting ownership of [${rabbitMQScriptFolder}] to [${RABBITMQ_USER}:${RABBITMQ_USER}] failed"
  local scriptFile="${COMPOSE_HOME}/third-party/rabbitmq/setRabbitCluster.sh"
  if [ ! -f "$scriptFile" ]; then
    scriptFile="${SCRIPT_HOME}/rabbitmq/setRabbitCluster.sh"
  fi

  [ -f "$scriptFile" ] || { warn "Could not find the file: [setRabbitCluster.sh]" && return; }

  cp "$scriptFile" "$rabbitMQScriptFolder" || errorExit "Could not copy setRabbitCluster.sh to the destination folder"

  if [[ "${JF_SHARED_RABBITMQ_TLS_ENABLED}" == "true" ]]; then
      rabbitMqPort="5671"
      amqpProtocol="amqps"
  fi

  docker_addToEnvFile JF_SHARED_RABBITMQ_PORT ${rabbitMqPort}

  setSystemValue "shared.rabbitMq.url" "$amqpProtocol://$(wrapper_getHostIP):$rabbitMqPort/"

  # Get the shared.rabbitMq.active.node.name. If this exists, this is a secondary node being setup
  _getYamlValueAndUpdateEnv "shared.rabbitMq.active.node.name" "JF_SHARED_RABBITMQ_ACTIVE_NODE_NAME" "$SYSTEM_YAML_FILE"

  local configFile="$rabbitMQScriptFolder/rabbitmq.conf"
  _createRabbitMQConf "$configFile"

  # Add or override rabbitmq configurations
  transformPropertiesToFile "${configFile}" "${SYS_KEY_RABBITMQ_NODE_RABBITMQCONF}" "${SYSTEM_YAML_FILE}" "${IGNORE_RABBITMQ_CONFIGS}"

  if [[ ${JF_SHARED_RABBITMQ_TLS_ENABLED} == true ]]; then
    removeProperty listeners.tcp.default "${configFile}" "="
 else
    propertyTransform "${configFile}" "listeners.tcp.default" "$rabbitMqPort"
  fi

  # The cookie should be owned & readable only by the rabbit mq user

  propertyTransform "${configFile}" "management.listener.ssl" "${JF_SHARED_RABBITMQ_TLS_ENABLED}"

  if [ ! -z "${JF_SHARED_RABBITMQ_ACTIVE_NODE_NAME}" ] && [ "${JF_SHARED_RABBITMQ_ACTIVE_NODE_NAME}" != "None" ]; then
    logDebug "Method ${FUNCNAME[0]} - slave node configuration"

    _getYamlValueAndUpdateEnv "shared.rabbitMq.active.node.ip" "JF_SHARED_RABBITMQ_ACTIVE_NODE_IP" "$SYSTEM_YAML_FILE"

    # If node ID or IP are not available, warn and abort
    if [ -z "${JF_SHARED_RABBITMQ_ACTIVE_NODE_NAME}" ] || [ -z "${JF_SHARED_RABBITMQ_ACTIVE_NODE_IP}" ]; then
      warn "Missing configuration [shared.rabbitMq.active.node] in [$SYSTEM_YAML_FILE]. RabbitMQ HA setup is incomplete. Please setup manually"
      return
    fi

    echo -e "\ncluster_formation.peer_discovery_backend = rabbit_peer_discovery_classic_config" >> "$configFile"
    echo -e "\ncluster_formation.classic_config.nodes.1 = rabbit@$JF_SHARED_RABBITMQ_ACTIVE_NODE_NAME" >> "$configFile"

    if [[ $(uname) != "Darwin" ]]; then
      chown ${RABBITMQ_USER}:${RABBITMQ_USER} "${configFile}"
      chmod u+rw "${configFile}"
      chmod go-rwx "${configFile}"
    fi
  fi

  io_setOwnership  "${rabbitMQScriptFolder}" "${RABBITMQ_USER}" "${RABBITMQ_USER}" || errorExit "Setting ownership of [${rabbitMQScriptFolder}] to [${RABBITMQ_USER}:${RABBITMQ_USER}] failed"
  io_setOwnership "${SYSTEM_YAML_FILE}" "$DOCKER_USER" "$DOCKER_USER"
}

createErlangCookie() {
  logDebug "Method ${FUNCNAME[0]}"
  local cookieFile=${RABBITMQ_DATA_ROOT}/.erlang.cookie

  if [ -f "${cookieFile}" ]; then
    logDebug "Erlang cookie (${cookieFile}) already exists, skipping its creation"
    return
  fi
  
  logDebug "Creating erlang cookie [$cookieFile] as [$JF_SHARED_RABBITMQ_ERLANGCOOKIE_VALUE]"
  echo "$JF_SHARED_RABBITMQ_ERLANGCOOKIE_VALUE" > "${cookieFile}"

  # The cookie should be owned & readable only by the rabbit mq user
  if [[ $(uname) != "Darwin" ]]; then
    chown ${RABBITMQ_USER}:${RABBITMQ_USER} "${cookieFile}"
    chmod u+rw "${cookieFile}"
    chmod go-rwx "${cookieFile}"
  fi
}

docker_hook_setupThirdParty() {
  logDebug "Method ${FUNCNAME[0]}"

  # Update the env with this host's name
  docker_addToEnvFile "HOST_ID" "$(io_getPublicHostID)"

  # Create an erlang cookie
  createErlangCookie

  setupRabbitMQCluster
  _transformRabbitMqPasswordToConfFile
}


docker_hook_updateFromYaml() {
  logDebug "Method ${FUNCNAME[0]}"
  _getYamlValueAndUpdateEnv "shared.rabbitMq.erlangCookie.value" "JF_SHARED_RABBITMQ_ERLANGCOOKIE_VALUE" "$1"
  _getYamlValueAndUpdateEnv "shared.rabbitMq.active.node.name" "JF_SHARED_RABBITMQ_ACTIVE_NODE_NAME" "$1"
  _getYamlValueAndUpdateEnv "shared.rabbitMq.active.node.ip" "JF_SHARED_RABBITMQ_ACTIVE_NODE_IP" "$1"
  _getYamlValueAndUpdateEnv "shared.rabbitMq.clean" "JF_SHARED_RABBITMQ_CLEAN" "$1"
}

docker_hook_postSystemYamlCreation() {
  logDebug "Method ${FUNCNAME[0]}"
  
  # Update the env with Bind IP
  docker_addToEnvFile "JF_THIRD_PARTY_BIND_IP" "${JF_SHARED_NODE_IP:-127.0.0.1}"

  if [ "$IS_POSTGRES_REQUIRED" == "$FLAG_Y" ]; then
    docker_setSystemValue "$SYS_KEY_SHARED_DATABASE_URL" "postgres://$(wrapper_getHostIP):5432/xraydb?sslmode=disable"
  fi
}

docker_hook_copyComposeFile() {
  logDebug "Method ${FUNCNAME[0]}"
  docker_setUpPostgresCompose

  local sourceFile="$COMPOSE_TEMPLATES/docker-compose.yaml"
  local targetFile="$COMPOSE_HOME/docker-compose.yaml"
  logDebug "Copying [$sourceFile] as [$targetFile]"
  cp "$sourceFile" "$targetFile"

  logDebug "Copying [$COMPOSE_TEMPLATES/$JFROG_RABBITMQ_COMPOSE_FILE] as [$COMPOSE_HOME/$JFROG_RABBITMQ_COMPOSE_FILE]"
  cp -f "${COMPOSE_TEMPLATES}/${JFROG_RABBITMQ_COMPOSE_FILE}" "${COMPOSE_HOME}/${JFROG_RABBITMQ_COMPOSE_FILE}"

  if _isMongoNotNeeded; then
    logDebug "Mongo entry does not exist. Removing mongo container"
    docker_removeSystemValue "services.mongodb" "$targetFile"
  fi
}

docker_hook_productSpecificComposeHelp(){
    case "${PRODUCT_NAME}" in
        $XRAY_LABEL)
        if [ ! -z ${JFROG_RABBITMQ_COMPOSE_FILE} ]; then
cat << END_USAGE

Rabbitmq is a dependent service which needs to be started once after install. This needs to be running before start of xray services.

start rabbitmq:      docker-compose -p ${JF_PROJECT_NAME}-rabbitmq -f ${JFROG_RABBITMQ_COMPOSE_FILE} up -d

END_USAGE
        fi
        ;;
    esac
}

docker_hook_preUserInputs(){
  wrapper_checkXrayArtPairing
}

FEATURE_FLAG_USE_WRAPPER="$FLAG_Y"
MANDATORY_FIELDS="JF_SHARED_JFROGURL JF_SHARED_SECURITY_JOINKEY"
EXTERNAL_DATABASES="$DATABASE_POSTGRES"
CLUSTER_DATABASES="$DATABASE_RABBITMQ"
DOCKER_USER=${XRAY_USER}
MIGRATION_SUPPORTED="$FLAG_Y"
JFROG_RABBITMQ_COMPOSE_FILE="docker-compose-rabbitmq.yaml"
docker_main $*