#!/bin/bash

ansible-playbook reset.yml
